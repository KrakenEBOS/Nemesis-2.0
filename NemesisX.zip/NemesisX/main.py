#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# NEMESIS — MAIN

import os
import sys
import platform
import time
import subprocess
import asyncio

# ======================== ПАРОЛЬ ========================
PASSWORD = "EBOS ALWAYS WIN"

def password_check():
    os.system("cls" if platform.system() == "Windows" else "clear")
    print("\033[91m" + "=" * 50)
    print("         NEMESIS — ВВЕДИТЕ ПАРОЛЬ")
    print("=" * 50 + "\033[0m")
    attempt = input("\033[91m[?] Пароль: \033[0m")
    if attempt != PASSWORD:
        print("\033[91m[!] НЕВЕРНЫЙ ПАРОЛЬ. ДОСТУП ЗАПРЕЩЕН.\033[0m")
        time.sleep(2)
        sys.exit(1)
    print("\033[92m[+] ДОСТУП РАЗРЕШЁН. ЗАГРУЗКА NEMESIS...\033[0m")
    time.sleep(1)

password_check()

# ======================== ПОДКЛЮЧЕНИЕ МОДУЛЕЙ ========================
modules_path = os.path.join(os.path.dirname(__file__), 'modules')
if modules_path not in sys.path:
    sys.path.insert(0, modules_path)

# Импорты
from banner import show_banner
from probiv import (
    search_phone, search_email, search_ip, search_nick,
    search_fio, search_password, search_vin, search_auto,
    search_mac, search_telegram, search_facebook, search_instagram,
    full_search_phone, full_search_social, domain_info,
    port_scanner, web_crawler, complex_password,
    fake_person, fake_card, strange_text, get_proxies
)
from manuals import show_manuals
from bloodtrail import BloodTrail
from tg_bomber import send_telegram_codes

# Импортируем сносер без автозапуска баннера
import importlib
snoser_mod = importlib.import_module('snoser_mod')

# Импортируем НОВЫЙ DDoS
from DDoS_Attack import main as ddos_main

# ======================== ЦВЕТА ========================
from colorama import Fore, init
init(autoreset=True)
R = Fore.RED
W = Fore.WHITE
Y = Fore.YELLOW
RESET = Fore.RESET

def print_bad(text): print(f"{R}[-] {W}{text}")
def print_good(text): print(f"{R}[+] {W}{text}")
def print_info(text): print(f"{R}[i] {W}{text}")
def get_input(prompt): return input(f"{R}[?] {W}{prompt}")
def pause(): input(f"\n{R}[!] {W}Нажми Enter для продолжения...{RESET}")

# ======================== ГЛАВНОЕ МЕНЮ ========================
def main():
    while True:
        try:
            show_banner()
            
            print(f"""
{R}═══════════════════════════════════════════════════════════════════════
{R}[{W} 1{R}] Поиск по номеру      [{W} 9{R}] Поиск по VIN         [{W}17{R}] Порт-сканер
{R}[{W} 2{R}] Поиск по почте       [{W}10{R}] Поиск по авто        [{W}18{R}] Web-краулер
{R}[{W} 3{R}] Поиск по IP          [{W}11{R}] Поиск по MAC         [{W}19{R}] Сложный пароль
{R}[{W} 4{R}] Поиск по нику        [{W}12{R}] Поиск по Telegram    [{W}20{R}] Вымышленная личность
{R}[{W} 5{R}] Поиск по ФИО         [{W}13{R}] Поиск по Facebook    [{W}21{R}] Вымышленная карта
{R}[{W} 6{R}] Поиск по паролю      [{W}14{R}] Поиск по Instagram   [{W}22{R}] Странный текст
{R}[{W} 7{R}] Инфа о сайте         [{W}15{R}] Полный пробив        [{W}23{R}] Прокси
{R}[{W} 8{R}] Поиск по Telegram    [{W}16{R}] Пробив по соцсетям   [{W}24{R}] DDOS атака
{R}
{R}[{W}25{R}] МАНУАЛЫ (9 шт)
{R}[{W}26{R}] SMS-БОМБЕР (BloodTrail)
{R}[{W}27{R}] ТГ-СНОСЕР (аккаунты/каналы/боты/чаты)
{R}[{W}28{R}] ТГ-БОМБЕР (коды)
{R}
{R}[{W}99{R}] Выход
{R}═══════════════════════════════════════════════════════════════════════
            """)
            
            choice = get_input("Введите номер функции -> ")
            
            if choice == "1": search_phone()
            elif choice == "2": search_email()
            elif choice == "3": search_ip()
            elif choice == "4": search_nick()
            elif choice == "5": search_fio()
            elif choice == "6": search_password()
            elif choice == "7": domain_info()
            elif choice == "8": search_telegram()
            elif choice == "9": search_vin()
            elif choice == "10": search_auto()
            elif choice == "11": search_mac()
            elif choice == "12": search_telegram()
            elif choice == "13": search_facebook()
            elif choice == "14": search_instagram()
            elif choice == "15": full_search_phone()
            elif choice == "16": full_search_social()
            elif choice == "17": port_scanner()
            elif choice == "18": web_crawler()
            elif choice == "19": complex_password()
            elif choice == "20": fake_person()
            elif choice == "21": fake_card()
            elif choice == "22": strange_text()
            elif choice == "23": get_proxies()
            elif choice == "24":
                # Запускаем НОВЫЙ DDoS
                ddos_main()
            elif choice == "25":
                show_manuals()
            elif choice == "26":
                print(f"\n{R}═══════════════════ SMS-БОМБЕР (BloodTrail) ═══════════════════{RESET}")
                phone = get_input("Введите номер телефона (+7XXXXXXXXX): ")
                runs = int(get_input("Количество циклов: ") or 5)
                
                async def run_bomber():
                    bomber = BloodTrail()
                    await bomber.start(phone, runs)
                
                try:
                    asyncio.run(run_bomber())
                except KeyboardInterrupt:
                    print("\n[!] Остановлено пользователем")
                except Exception as e:
                    print_bad(f"Ошибка: {str(e)}")
            elif choice == "27":
                print(f"\n{R}═══════════════════ ТГ-СНОСЕР ═══════════════════{RESET}")
                snoser_mod.main()
            elif choice == "28":
                send_telegram_codes()
            elif choice in ["99", "0", "exit", "quit", "q"]:
                print(f"\n{R}Ты уходишь. Но Nemesis всегда будет ждать.{RESET}")
                sys.exit(0)
            else:
                print_bad("Неверный выбор.")
            
            pause()
            
        except KeyboardInterrupt:
            print(f"\n\n{R}[!] Прервано.{RESET}")
            sys.exit(0)
        except Exception as e:
            print_bad(f"Ошибка: {str(e)}")
            pause()

if __name__ == "__main__":
    main()