#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import socket
import requests
import phonenumbers
from phonenumbers import carrier, geocoder, timezone as pn_timezone
import whois
import dns.resolver
import ipaddress
import time
import random
import string
import hashlib
import base64
import bs4
from urllib.parse import quote, urlparse
from fake_useragent import UserAgent
from concurrent.futures import ThreadPoolExecutor, as_completed
import validate_email

from colorama import Fore
R = Fore.RED
W = Fore.WHITE
Y = Fore.YELLOW
RESET = Fore.RESET

def print_good(text): print(f"{R}[+] {W}{text}")
def print_bad(text): print(f"{R}[-] {W}{text}")
def print_info(text): print(f"{R}[i] {W}{text}")
def print_warn(text): print(f"{R}[!] {W}{text}")
def get_input(prompt): return input(f"{R}[?] {W}{prompt}")

def clean_phone(phone):
    return re.sub(r'[^0-9+]', '', phone)

def clean_mac(mac):
    return re.sub(r'[^0-9A-Fa-f]', '', mac).upper()

def is_valid_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except:
        return False

def is_valid_email(email):
    try:
        return validate_email.validate_email(email)
    except:
        return False

def get_user_agent():
    return UserAgent().random

# ======================== ПОИСК ПО НОМЕРУ ========================
def search_phone():
    phone = get_input("Введите номер телефона: ")
    phone = clean_phone(phone)
    print(f"\n{R}═══════════════════ ПОИСК ПО НОМЕРУ ═══════════════════{RESET}")
    
    try:
        parsed = phonenumbers.parse(phone, None)
        if phonenumbers.is_valid_number(parsed):
            print_good(f"Номер: {phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}")
            print_good(f"Страна: {geocoder.description_for_number(parsed, 'ru')}")
            print_good(f"Регион: {geocoder.description_for_number(parsed, 'en')}")
            print_good(f"Оператор: {carrier.name_for_number(parsed, 'ru') or 'Неизвестно'}")
            print_good(f"Таймзона: {', '.join(pn_timezone.time_zones_for_number(parsed))}")
    except:
        print_warn("Неверный формат номера")
    
    print_info("Поиск в соцсетях...")
    clean = re.sub(r'[^0-9]', '', phone)
    print(f"  Telegram: https://t.me/{phone}")
    print(f"  WhatsApp: https://wa.me/{clean}")
    print(f"  Viber: https://viber.click/{clean}")
    print(f"  Signal: https://signal.me/#p/{clean}")
    print(f"  TrueCaller: https://www.truecaller.com/search/{clean}")
    print(f"  SocSearch: https://socsearch.io/search/{clean}")
    print(f"  PhoneInfoga: https://phoneinfoga.cert.ovh/{clean}")
    print(f"  NumLookup: https://www.numlookup.com/{clean}")
    print(f"  SpyDialer: https://spydialer.com/{clean}")
    
    # Реальные API
    try:
        r = requests.get(f"https://api.numlookup.com/phone/{phone}", timeout=5)
        if r.status_code == 200:
            data = r.json()
            if data.get('valid'):
                print_good(f"NumLookup: {data.get('location')} {data.get('carrier')}")
    except:
        pass
    
    try:
        r = requests.get(f"https://www.truecaller.com/api/v1/search?phone={phone}", 
                        headers={"User-Agent": get_user_agent()}, timeout=5)
        if r.status_code == 200:
            data = r.json()
            if 'data' in data and 'name' in data['data']:
                print_good(f"TrueCaller: {data['data']['name']}")
    except:
        pass

# ======================== ПОИСК ПО ПОЧТЕ ========================
def search_email():
    email = get_input("Введите email: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО ПОЧТЕ ═══════════════════{RESET}")
    
    try:
        r = requests.get(f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}", timeout=5)
        if r.status_code == 200:
            breaches = r.json()
            print_good(f"Найдено утечек: {len(breaches)}")
            for b in breaches[:5]:
                print(f"  {Y}- {b['Name']} ({b.get('BreachDate', 'Неизвестно')})")
    except:
        pass
    
    try:
        r = requests.get(f"https://emailrep.io/{email}", timeout=5)
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                print_good(f"Репутация: {data.get('reputation')}")
                print_good(f"Спам: {data.get('suspicious')}")
    except:
        pass
    
    username = email.split('@')[0]
    sites = [
        ("GitHub", f"https://github.com/{username}"),
        ("Twitter", f"https://twitter.com/{username}"),
        ("Instagram", f"https://instagram.com/{username}"),
        ("VK", f"https://vk.com/{username}"),
    ]
    for name, url in sites:
        try:
            r = requests.get(url, timeout=3, headers={"User-Agent": get_user_agent()})
            if r.status_code == 200:
                print_good(f"{name}: найден")
        except:
            pass
    
    print(f"\n{Y}[+] Ссылки:{RESET}")
    print(f"  DeHashed: https://dehashed.com/search?query={email}")
    print(f"  IntelX: https://intelx.io/?s={email}")
    print(f"  LeakCheck: https://leakcheck.net/search?query={email}")
    print(f"  EmailRep: https://emailrep.io/{email}")
    print(f"  HaveIBeenPwned: https://haveibeenpwned.com/account/{email}")

# ======================== ПОИСК ПО IP ========================
def search_ip():
    ip = get_input("Введите IP-адрес: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО IP ═══════════════════{RESET}")
    
    if not is_valid_ip(ip):
        print_bad("Неверный IP")
        return
    
    try:
        r = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
        data = r.json()
        if data.get('status') == 'success':
            print_good(f"Страна: {data.get('country')}")
            print_good(f"Регион: {data.get('regionName')}")
            print_good(f"Город: {data.get('city')}")
            print_good(f"Провайдер: {data.get('isp')}")
            print_good(f"Координаты: {data.get('lat')}, {data.get('lon')}")
            print_good(f"Часовой пояс: {data.get('timezone')}")
    except:
        pass
    
    try:
        r = requests.get(f"https://ipinfo.io/{ip}/json", timeout=5)
        data = r.json()
        if 'city' in data:
            print_good(f"IPinfo - Город: {data.get('city')}")
            print_good(f"IPinfo - Регион: {data.get('region')}")
            print_good(f"IPinfo - Страна: {data.get('country')}")
    except:
        pass
    
    print(f"\n{Y}[+] Ссылки:{RESET}")
    print(f"  Shodan: https://www.shodan.io/host/{ip}")
    print(f"  AbuseIPDB: https://www.abuseipdb.com/check/{ip}")
    print(f"  VirusTotal: https://www.virustotal.com/gui/ip-address/{ip}")

# ======================== ПОИСК ПО НИКУ ========================
def search_nick():
    nick = get_input("Введите никнейм: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО НИКУ ═══════════════════{RESET}")
    
    platforms = [
        ("Instagram", f"https://www.instagram.com/{nick}/"),
        ("TikTok", f"https://www.tiktok.com/@{nick}"),
        ("Twitter", f"https://twitter.com/{nick}"),
        ("Facebook", f"https://www.facebook.com/{nick}"),
        ("YouTube", f"https://www.youtube.com/@{nick}"),
        ("Telegram", f"https://t.me/{nick}"),
        ("Twitch", f"https://www.twitch.tv/{nick}"),
        ("Reddit", f"https://www.reddit.com/user/{nick}"),
        ("GitHub", f"https://github.com/{nick}"),
        ("VK", f"https://vk.com/{nick}"),
        ("Pinterest", f"https://pinterest.com/{nick}/"),
        ("Tumblr", f"https://{nick}.tumblr.com/"),
        ("Flickr", f"https://www.flickr.com/people/{nick}/"),
        ("Dribbble", f"https://dribbble.com/{nick}"),
        ("Behance", f"https://www.behance.net/{nick}"),
        ("SoundCloud", f"https://soundcloud.com/{nick}"),
        ("Steam", f"https://steamcommunity.com/id/{nick}/"),
        ("Spotify", f"https://open.spotify.com/user/{nick}"),
        ("Medium", f"https://medium.com/@{nick}"),
        ("Dev.to", f"https://dev.to/{nick}"),
        ("HackerNews", f"https://news.ycombinator.com/user?id={nick}"),
        ("ProductHunt", f"https://www.producthunt.com/@{nick}"),
        ("Keybase", f"https://keybase.io/{nick}"),
        ("Pastebin", f"https://pastebin.com/u/{nick}"),
        ("Roblox", f"https://www.roblox.com/user.aspx?username={nick}"),
        ("LinkedIn", f"https://www.linkedin.com/in/{nick}/"),
        ("Imgur", f"https://imgur.com/user/{nick}"),
        ("Patreon", f"https://www.patreon.com/{nick}"),
        ("GitLab", f"https://gitlab.com/{nick}"),
        ("Bitbucket", f"https://bitbucket.org/{nick}/"),
        ("HackTheBox", f"https://www.hackthebox.com/profile/{nick}"),
        ("TryHackMe", f"https://tryhackme.com/p/{nick}"),
        ("Clubhouse", f"https://www.clubhouse.com/@{nick}"),
        ("Discord", f"https://discord.com/users/{nick}"),
        ("Signal", f"https://signal.me/#p/{nick}"),
    ]
    
    for name, url in platforms:
        try:
            r = requests.get(url, timeout=3, headers={"User-Agent": get_user_agent()})
            if r.status_code == 200:
                print_good(f"{name}: найден")
        except:
            pass

# ======================== ПОИСК ПО ФИО ========================
def search_fio():
    fio = get_input("Введите ФИО: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО ФИО ═══════════════════{RESET}")
    
    sites = [
        ("VK", f"https://vk.com/search?c[section]=people&c[q]={quote(fio)}"),
        ("Instagram", f"https://www.instagram.com/explore/search/?q={fio}"),
        ("Facebook", f"https://www.facebook.com/search/people/?q={fio}"),
        ("Twitter", f"https://twitter.com/search?q={fio}"),
        ("TikTok", f"https://www.tiktok.com/search?q={fio}"),
        ("LinkedIn", f"https://www.linkedin.com/search/results/people/?keywords={fio}"),
        ("Одноклассники", f"https://ok.ru/search?st.query={fio}"),
        ("YouTube", f"https://www.youtube.com/results?search_query={fio}"),
    ]
    for name, url in sites:
        print(f"  {Y}{name}: {W}{url}")
    
    print(f"\n{Y}[+] Госреестры:{RESET}")
    print(f"  ФНС: https://egrul.nalog.ru/index.html")
    print(f"  ФССП: https://fssp.gov.ru/")
    print(f"  Суды: https://sudrf.ru/")
    print(f"  Росреестр: https://rosreestr.gov.ru/")

# ======================== ПОИСК ПО ПАРОЛЮ ========================
def search_password():
    password = get_input("Введите пароль: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО ПАРОЛЮ ═══════════════════{RESET}")
    
    try:
        sha1 = hashlib.sha1(password.encode()).hexdigest().upper()
        prefix = sha1[:5]
        r = requests.get(f"https://api.pwnedpasswords.com/range/{prefix}", timeout=5)
        if r.status_code == 200:
            for line in r.text.splitlines():
                suffix, count = line.split(':')
                if sha1[5:] == suffix:
                    print_warn(f"Пароль найден в утечках! Количество: {count}")
                    break
            else:
                print_good("Пароль не найден в утечках")
    except:
        pass

# ======================== ПОИСК ПО VIN ========================
def search_vin():
    vin = get_input("Введите VIN: ").upper()
    print(f"\n{R}═══════════════════ ПОИСК ПО VIN ═══════════════════{RESET}")
    if len(vin) != 17:
        print_warn("VIN должен содержать 17 символов")
    print(f"  VINinfo: https://www.vininfo.ru/vin.php?vin={vin}")
    print(f"  VINDecoder: https://www.vin-decoder.org/")
    print(f"  AutoCheck: https://www.autocheck.com/vehiclehistory/")
    print(f"  Carfax: https://www.carfax.com/")

# ======================== ПОИСК ПО АВТО ========================
def search_auto():
    plate = get_input("Введите номер авто: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО АВТО ═══════════════════{RESET}")
    print(f"  Автокод: https://avtokod.ru/check/{plate}")
    print(f"  ГИБДД: http://www.gibdd.ru/check/auto/")
    print(f"  Автотека: https://avtoteka.ru/")
    print(f"  Carfax: https://www.carfax.com/")

# ======================== ПОИСК ПО MAC ========================
def search_mac():
    mac = get_input("Введите MAC-адрес: ")
    mac = clean_mac(mac)
    if len(mac) != 12:
        print_bad("Неверный MAC")
        return
    print(f"\n{R}═══════════════════ ПОИСК ПО MAC ═══════════════════{RESET}")
    try:
        r = requests.get(f"https://api.macvendors.com/{mac}", timeout=5)
        if r.status_code == 200:
            print_good(f"Производитель: {r.text.strip()}")
    except:
        pass

# ======================== ПОИСК ПО TELEGRAM ========================
def search_telegram():
    tg_id = get_input("Введите Telegram ID: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО TELEGRAM ═══════════════════{RESET}")
    print(f"  Telegram: https://t.me/{tg_id}")
    print(f"  TGScan: https://tgscan.ru/user/{tg_id}")
    print(f"  TGStat: https://tgstat.ru/channel/@{tg_id}")
    print(f"  Telemetr: https://telemetr.me/@{tg_id}")

def search_facebook():
    fb_id = get_input("Введите Facebook ID: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО FACEBOOK ═══════════════════{RESET}")
    print(f"  Facebook: https://www.facebook.com/{fb_id}")
    print(f"  SocialSearch: https://socsearch.io/search/{fb_id}")

def search_instagram():
    ig_id = get_input("Введите Instagram ID: ")
    print(f"\n{R}═══════════════════ ПОИСК ПО INSTAGRAM ═══════════════════{RESET}")
    print(f"  Instagram: https://www.instagram.com/{ig_id}/")
    print(f"  Picuki: https://www.picuki.com/profile/{ig_id}")
    print(f"  ImgInn: https://imginn.com/{ig_id}/")

# ======================== ПОЛНЫЙ ПРОБИВ ========================
def full_search_phone():
    print(f"\n{R}═══════════════════ ПОЛНЫЙ ПРОБИВ ═══════════════════{RESET}")
    query = get_input("Введите номер телефона или ФИО: ")
    
    if re.search(r'[0-9]', query):
        search_phone()
    else:
        search_fio()
    
    print_info("Поиск в утечках...")
    try:
        r = requests.get(f"https://haveibeenpwned.com/api/v3/breachedaccount/{query}", timeout=5)
        if r.status_code == 200:
            breaches = r.json()
            print_good(f"Найдено утечек: {len(breaches)}")
    except:
        pass

def full_search_social():
    print(f"\n{R}═══════════════════ ПРОБИВ ПО СОЦСЕТЯМ ═══════════════════{RESET}")
    nick = get_input("Введите никнейм: ")
    search_nick()

# ======================== ИНФА О САЙТЕ ========================
def domain_info():
    domain = get_input("Введите домен: ")
    print(f"\n{R}═══════════════════ ИНФОРМАЦИЯ О САЙТЕ ═══════════════════{RESET}")
    
    try:
        w = whois.whois(domain)
        print_good(f"Домен: {w.domain_name}")
        print_good(f"Создан: {w.creation_date}")
        print_good(f"Истекает: {w.expiration_date}")
        print_good(f"Регистратор: {w.registrar}")
    except:
        pass
    
    try:
        print(f"\n{Y}[+] DNS записи:{RESET}")
        for record in ['A', 'MX', 'NS']:
            try:
                answers = dns.resolver.resolve(domain, record)
                print_good(f"{record}: {', '.join([str(r) for r in answers])}")
            except:
                pass
    except:
        pass

# ======================== ПОРТ-СКАНЕР ========================
def port_scanner():
    target = get_input("Хост (127.0.0.1): ") or "127.0.0.1"
    ports = [20, 21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445,
             993, 995, 1723, 3306, 3389, 5432, 5900, 6379, 8080, 8443]
    
    print(f"\n{R}═══════════════════ СКАНИРОВАНИЕ ПОРТОВ ═══════════════════{RESET}")
    print_info(f"Цель: {target}, Портов: {len(ports)}")
    
    def scan_port(port):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        try:
            result = sock.connect_ex((target, port))
            sock.close()
            return result == 0
        except:
            return False
    
    open_ports = []
    with ThreadPoolExecutor(max_workers=100) as executor:
        futures = {executor.submit(scan_port, port): port for port in ports}
        for future in as_completed(futures):
            port = futures[future]
            if future.result():
                open_ports.append(port)
                print_good(f"Порт {port} ОТКРЫТ")
    
    if open_ports:
        print(f"\n{Y}[+] Открытые порты: {', '.join(map(str, open_ports))}")
    else:
        print_bad("Открытые порты не найдены")

# ======================== WEB-КРАУЛЕР ========================
def web_crawler():
    url = get_input("Стартовый URL: ")
    depth = min(int(get_input("Глубина (1-3): ") or 2), 3)
    domain = urlparse(url).netloc
    
    visited = set()
    queue = [(url, 0)]
    found = []
    
    print(f"\n{R}═══════════════════ КРАУЛИНГ ═══════════════════{RESET}")
    
    while queue and len(found) < 100:
        current_url, d = queue.pop(0)
        if current_url in visited or d > depth:
            continue
        visited.add(current_url)
        found.append(current_url)
        print(f"{R}[+] {W}{current_url}")
        
        try:
            r = requests.get(current_url, timeout=5, headers={"User-Agent": get_user_agent()})
            soup = bs4.BeautifulSoup(r.text, 'html.parser')
            for link in soup.find_all('a', href=True):
                href = link['href']
                if href.startswith('/'):
                    href = f"https://{domain}{href}"
                elif not href.startswith('http'):
                    continue
                if domain in href and href not in visited:
                    queue.append((href, d + 1))
        except:
            continue
    
    print_good(f"Найдено {len(found)} страниц")

# ======================== ГЕНЕРАТОР ПАРОЛЕЙ ========================
def complex_password():
    length = int(get_input("Длина пароля: "))
    complexity = get_input("Сложность (low/medium/high): ").lower()
    
    chars = string.ascii_lowercase + string.digits
    if complexity == "medium":
        chars += "!@#$%^&*()_+-=[]{}|;:,.<>?"
    elif complexity == "high":
        chars += string.punctuation + "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
    
    print(f"\n{R}═══════════════════ ПАРОЛИ ═══════════════════{RESET}")
    passwords = []
    for i in range(10):
        p = ''.join(random.choice(chars) for _ in range(length))
        passwords.append(p)
        print(f"  {R}{i+1:2}. {W}{p}")

# ======================== ВЫМЫШЛЕННАЯ ЛИЧНОСТЬ ========================
def fake_person():
    from faker import Faker
    fake = Faker('ru_RU')
    print(f"\n{R}═══════════════════ ВЫМЫШЛЕННАЯ ЛИЧНОСТЬ ═══════════════════{RESET}")
    print_good(f"ФИО: {fake.last_name()} {fake.first_name()} {fake.middle_name()}")
    print_good(f"Дата рождения: {fake.date_of_birth().strftime('%d.%m.%Y')}")
    print_good(f"Адрес: {fake.street_address()}, {fake.city()}")
    print_good(f"Email: {fake.email()}")
    print_good(f"Телефон: {fake.phone_number()}")

def fake_card():
    print_warn("Генератор карт — для тестов")
    print(f"\n{R}═══════════════════ ВЫМЫШЛЕННАЯ КАРТА ═══════════════════{RESET}")
    def gen_card():
        bin = random.choice(["4", "5", "2", "3"]) + ''.join(str(random.randint(0,9)) for _ in range(5))
        acc = ''.join(str(random.randint(0,9)) for _ in range(9))
        card = bin + acc
        digits = [int(x) for x in card]
        for i in range(len(digits)-1, -1, -2):
            digits[i] *= 2
            if digits[i] > 9:
                digits[i] -= 9
        checksum = (10 - (sum(digits) % 10)) % 10
        card += str(checksum)
        return card
    print_good(f"Номер: {gen_card()}")
    print_good(f"Срок: {random.randint(1,12):02d}/{random.randint(24,30)}")
    print_good(f"CVV: {random.randint(100,999)}")

def strange_text():
    text = get_input("Введите текст: ")
    result = ''.join({'а':'@','е':'3','о':'0','с':'5','т':'7','б':'6','з':'2'}.get(c,c) for c in text.lower())
    print(f"\n{R}═══════════════════ РЕЗУЛЬТАТ ═══════════════════{RESET}")
    print_good(f"Оригинал: {text}")
    print_good(f"Преобразовано: {result}")

def get_proxies():
    print_info("Сбор прокси...")
    urls = [
        "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
        "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list.txt",
    ]
    proxies = []
    for url in urls:
        try:
            r = requests.get(url, timeout=10)
            proxies.extend([p.strip() for p in r.text.split('\n') if p.strip() and ':' in p])
        except:
            continue
    proxies = list(set(proxies))[:100]
    print_good(f"Загружено {len(proxies)} прокси")